makeindex -s coppe.ist -o .texpadtmp/principal.lab .texpadtmp/principal.abx
makeindex -s coppe.ist -o .texpadtmp/principal.los .texpadtmp/principal.syx
